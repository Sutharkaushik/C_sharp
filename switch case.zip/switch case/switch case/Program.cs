﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace switch_case
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("set Console color Red=1");
            Console.WriteLine("set Console color Blue=2");
            Console.WriteLine("set Console color White=3");
            int n = Convert.ToInt32(Console.ReadLine());

            switch (n)
            {
                case 1: Console.BackgroundColor = ConsoleColor.Red;
                    Console.Clear();
                    break;
                case 2: Console.BackgroundColor = ConsoleColor.Blue;
                    Console.Clear();
                    break;
                case 3: Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;

            }
            Console.Read();
        }
    }
}
